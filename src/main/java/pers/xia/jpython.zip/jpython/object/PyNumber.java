package pers.xia.jpython.object;

import java.math.BigInteger;

public class PyNumber extends PyObject
{
    BigInteger num;
    
    public PyNumber(String s)
    {
    }
}
