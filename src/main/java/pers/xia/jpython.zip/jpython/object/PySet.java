package pers.xia.jpython.object;

public class PySet extends PyObject{
	
	public PySet(PyObject iterable)
	{
		
	}
}
