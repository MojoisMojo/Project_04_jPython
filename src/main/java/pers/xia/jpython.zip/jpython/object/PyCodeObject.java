package pers.xia.jpython.object;

public class PyCodeObject extends PyObject
{

}
